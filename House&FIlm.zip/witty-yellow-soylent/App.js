import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ImageBackground } from 'react-native';

export default function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (username === 'admin' && password === '1234') {
      Alert.alert('Login bem-sucedido!', `Bem-vindo, ${username}!`);
    } else {
      Alert.alert('Erro', 'Nome de usuário ou senha incorretos.');
    }
  };

  return (
    <ImageBackground
      source={{ uri: 'https://wallpapers.com/images/hd/haku-spirited-away-phone-wallpaper-dpvx6yigeya94uhq.jpg' }}
      style={styles.background}
    >
      <View style={styles.container}>
        <Text style={styles.title}>Tela de Login</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite seu nome de usuário"
          value={username}
          onChangeText={setUsername}
        />
        <TextInput
          style={styles.input}
          placeholder="Digite sua senha"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
        />
        <Button title="Login" onPress={handleLogin} />
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1, // Faz o fundo ocupar toda a tela
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.8)', // Fundo semitransparente para os componentes
    padding: 16,
    borderRadius: 10,
  },
  title: {
    fontSize: 24,
    marginBottom: 16,
    color: '#333', // Cor do texto
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
    backgroundColor: '#fff', // Fundo branco para os campos de entrada
    borderRadius: 8,
  },
});
